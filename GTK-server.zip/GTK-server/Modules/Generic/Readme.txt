======================
Intro
======================

The DLL is just another way the GTK-server can provide GUI access. It is *not* needed for the 'GTK-server.exe' to run.

Please make sure DLL can find the 'gtk-server.cfg' file. You can put this file in the same directory as your client script. Also the environment variable 'GTK_SERVER_CONFIG' may point to this file. Or in your first call to the 'gtk' function, enter the location of the configfile (see demoscript in this directory).

======================
API
======================

gtk (string argument)

Send your GTK call as a string in s-expression format to this function. It will return a string as result.

Example:

gtk("gtk_init NULL NULL")


-----------------------------------------------------------------------------

In your script, import this function. See the 'demo-lib.lsp' demoscript.


======================
Good luck,
Peter
