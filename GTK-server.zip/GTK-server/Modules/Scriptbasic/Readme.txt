Installation

1) Put the gtk-server.dll file in your Scriptbasic 'modules' directory

2) Put the gtk.bas file in your Scriptbasic 'include' directory

3) Run the demo program!

Please make sure DLL can find the 'gtk-server.cfg' file. You can put the configfile in the same directory as your client script. Also the environment variable 'GTK_SERVER_CONFIG' may point to this file. Or in your first call to the 'gtk' function, enter the location of the configfile (see demoscript in this directory).