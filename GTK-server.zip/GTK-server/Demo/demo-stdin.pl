% Demonstration on how to use the GTK-server with Gnu PROLOG by STDIN.
% Tested with Gnu PROLOG 1.2.16 on Linux Slackware 9.1 and WindowsXP.
%
% June 3, 2004 by Peter van Eerten.
% Revised at july 24, 2004.
%
% Run with gprolog. Compile with 'gplc demo.pl'.
% Revised for GTK-server 1.2 October 7, 2004
% Revised for GTK-server 1.3 December 6, 2004
%

:-initialization(start).

start:-
	init(Pin, Pout),
	main(Pin, Pout),
	leave(Pin, Pout).

init(Pin, Pout):-
	% Start server in STDIN mode
	exec('gtk-server stdin', Pout, Pin, _, _),
	% Switch to line buffering
	set_stream_buffering(Pout, line).

% Communicate with GTK-server
api(Pin, Pout, Txt, Result):-
	% Write string to stdin, terminate with newline
	write(Pout, Txt), write(Pout, '\n'),
	% Flush buffers
	flush_output(Pout),
	% Read info
	read_token(Pin, Result).

% This is the concatenate predicate
cat([], _).
cat([H|T], Stream):-
	write(Stream, H),
	cat(T, Stream).

% Concatenate list and communicate
gtk(Pin, Pout, List, Result):-
	open_output_atom_stream(Stream),
	cat(List, Stream),
	close_output_atom_stream(Stream, Text),
	api(Pin, Pout, Text, Result).

main(Pin, Pout):-
	% Initialize GTK
	gtk(Pin, Pout, [' gtk_init NULL NULL'], _),
	% Define window
	gtk(Pin, Pout, [' gtk_window_new 0'], WIN),
	gtk(Pin, Pout, [' gtk_window_set_title ', WIN, ' "GTK-server with STDIN"'], _),
	gtk(Pin, Pout, [' gtk_widget_set_usize ', WIN, ' 350 200'], _),
	% Define Table
	gtk(Pin, Pout, [' gtk_table_new 10 10 1'], TABLE),
	gtk(Pin, Pout, [' gtk_container_add ', WIN, ' ', TABLE], _),
	% Define button
	gtk(Pin, Pout, [' gtk_button_new_with_label "Button with label"'], BUTTON),
	gtk(Pin, Pout, [' gtk_table_attach_defaults ', TABLE, ' ', BUTTON, ' 5 9 5 9'], _),
	% Show widgets
	gtk(Pin, Pout, [' gtk_widget_show_all ', WIN], _),
	% Main
	repeat,
		gtk(Pin, Pout, [' gtk_server_callback WAIT'], EVENT),
	EVENT == BUTTON, !.

leave(Pin, Pout):-
	% Exit GTK
	gtk(Pin, Pout, [' gtk_exit 0'], _),
	% Exit Prolog - if you do not want to exit, use a cut (!).
	halt.
