% Demonstration on how to use the GTK-server with Gnu PROLOG by TCP.
% Tested with Gnu PROLOG 1.2.16 on Slackware Linux 9.1 and WindowsXP.
%
% October 27, 2003 by Peter van Eerten.
% Revised at july 24, 2004.
% Revised for GTK-server 1.2 October 8, 2004 by PvE.
% Revised for GTK-server 1.3 December 6, 2004 by PvE.
%
% Run with gprolog. Compile with 'gplc demo.pl'.
%
:-initialization(start).

start:-
	init(Socket, In, Out),
	main(In, Out),
	leave(Socket, In, Out).

init(Socket, In, Out):-
	% Start server in TCP mode
	exec('gtk-server tcp=localhost:40000', _, _, _, _),
	% Wait for the server to initialize
	sleep(1),
	% Define socket
	socket('AF_INET', Socket),
	% Try to connect
	socket_connect(Socket, 'AF_INET'(localhost, 40000), In, Out).

% Commmunicate with the GTK-server
api(In, Out, Txt, Result):-
	% Write string to socket
	write(Out, Txt),
	% Force flush on socket
	flush_output(Out),
	% Read info
	read_token(In, Result).

% This is the concatenate predicate
cat([], _).
cat([H|T], Stream):-
	write(Stream, H),
	cat(T, Stream).

% Concatenate list and communicate
gtk(In, Out, List, Result):-
	open_output_atom_stream(Stream),
	cat(List, Stream),
	close_output_atom_stream(Stream, Text),
	api(In, Out, Text, Result).

main(In, Out):-
	% Initialize GTK
	gtk(In, Out, ['gtk_init NULL NULL'], _),
	% Define window
	gtk(In, Out, ['gtk_window_new 0'], WIN),
	gtk(In, Out, ['gtk_window_set_title ', WIN, ' "GTK-server with TCP"'], _),
	gtk(In, Out, ['gtk_widget_set_usize ', WIN, ' 350 200'], _),
	% Define Table
	gtk(In, Out, ['gtk_table_new 10 10 1'], TABLE),
	gtk(In, Out, ['gtk_container_add ', WIN, ' ', TABLE], _),
	% Define button
	gtk(In, Out, ['gtk_button_new_with_label "Button with label"'], BUTTON),
	gtk(In, Out, ['gtk_table_attach_defaults ', TABLE, ' ', BUTTON, ' 5 9 5 9'], _),
	% Show widgets
	gtk(In, Out, ['gtk_widget_show_all ', WIN], _),
	% Mainloop
	repeat,
		gtk(In, Out, ['gtk_server_callback WAIT'], EVENT),
	EVENT == BUTTON, !.

leave(Socket, In, Out):-
	% Exit GTK
	gtk(In, Out, ['gtk_exit 0'], _),
	% Close socket
	socket_close(Socket),
	% Exit Prolog - if you do not want to exit, use a cut (!).
	halt.
